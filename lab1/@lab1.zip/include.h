/* Edison Zhang */
#define INIT 1
