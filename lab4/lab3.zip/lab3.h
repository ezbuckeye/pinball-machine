/* Neil Kirby */

bool init();
int main();
void read_and_run();
void teardown();
