/* Edison Zhang */

int foo(int x);
int main();
int mult_two(int x);
