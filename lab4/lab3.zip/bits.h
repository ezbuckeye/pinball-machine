/* Neil Kirby */

int get_color(unsigned char bits);
unsigned char set_in_play(unsigned char bits);
