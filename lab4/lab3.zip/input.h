/* Neil Kirby */

bool read_all(struct Sim *table);
