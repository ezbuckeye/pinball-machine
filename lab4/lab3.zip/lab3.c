

/* Copyright 2023, Neil Kirby.  Not for disclosure without permission */

/* system includes go first */
#include <stdio.h>
#include <stdbool.h>
#include "libpb.h"

/* includes for constants and tyupes are next */
#include "debug.h"
#include "constants.h"
#include "structs.h"

/* includes for functions go last */
#include "n2.h"
#include "input.h"
#include "sim.h"
#include "lab3.h"


bool init()
{
	return(TEXT || ( GRAPHICS && pb_initialize()));

}
void teardown()
{
	if(GRAPHICS)pb_teardown();
}

void read_and_run()
{
	struct Sim Balley = { 0.0, 0, NULL, NULL};
	struct Sim *table = &Balley;

	if( read_all(table))run_sim(table);
}


int main()
{
	double start, runtime;

	start = now();	// this is the very first executable statement

	if( init())
	{
	    read_and_run();
	    teardown();
	}

	/* at this point we are done, graphics has been torn down*/
	runtime = now() - start;
	/* after graphics has been torn down, we can freely print */
	printf("Total runtime is %.9lf seconds\n", runtime);

	return 0;
}

