/* Neil Kirby */

void final_output(struct Sim *table);
void launch_message( struct Ball *bp);
void left_flipper_message( struct Ball *bp);
void left_message( struct Ball *bp);
void load_message( struct Ball *bp);
void master_output(struct Sim *table);
void off_message( struct Ball *bp);
void points_message(int points);
void print_ball(void *data);
void print_ball_scores(void *data);
void right_flipper_message( struct Ball *bp);
void right_message( struct Ball *bp);
void top_message( struct Ball *bp);
