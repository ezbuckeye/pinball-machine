
/* Copyright 2023, Neil Kirby.  Not for disclosure without permission */

/* system includes go first */
#include <stdio.h>

#include "libpb.h"
#include "n2.h"
#include "linkedlist.h"

/* includes for constants and tyupes are next */
#include "debug.h"
#include "constants.h"
#include "structs.h"

/* includes for functions go last */
#include "bits.h"
#include "sim.h"
#include "output.h"

/* functions internal to this file go here at the top */

static void print_header(double et, int score)
{
	/* VY can hit -100, so it needs more room */
	printf("\n%2s    %9s %9s    %9s %10s    ET=%9.6lf  Score=%4d\n",
	"ST", "___X_____", "___Y_____", "___VX____", "____VY____", et,score);

}

/* an action function */
void print_ball_scores(void *data)
{
	struct Ball *bp = data;

	printf("%02X    %3d points\n", bp->bits, ball_score(bp) );
}

/* an action function */
void print_ball(void *data)
{
	struct Ball *bp = data;

	/* VY can hit -100, so it needs more room */
	printf("%02X    %9.5lf %9.5lf    %9.5lf %10.5lf\n",
	    bp->bits, bp->X, bp->Y, bp->VX, bp->VY );

}

static void draw_ball(void *data)
{
	struct Ball *bp = data;

	pb_ball(get_color(bp->bits), bp->X, bp->Y);
}

static void master_text(struct Sim *table)
{
	sort(table->playlist, sort_by_Y);
	print_header(table->et, table->score);
	iterate( table->playlist, print_ball);
	printf("\n");
}

static void master_graphics(struct Sim *table)
{
	pb_clear();
	pb_time( (int) (table->et * 1000.0));
	pb_score(table->score);
	iterate( table->playlist, draw_ball);
	pb_refresh();

	microsleep( (unsigned int)(DELTA_T * 1000000.0));
}


static void final_graphics(struct Sim *table)
{
        double wait = 0.0;

        while(wait < 4.0)
        {
            pb_clear();
            pb_time( (int) table->et * 1000);
	    pb_score(table->score);
            pb_refresh();

            microsleep( (unsigned int)(DELTA_T * 1000000.0));
            wait += DELTA_T;
        }
}

static void final_text(struct Sim *table)
{
	printf("\nThe final scores was %d points:\n", table->score);
	iterate(table->offlist, print_ball_scores);
	printf("\n");
}
/* public functions below here **********************************/

void master_output(struct Sim *table)
{
	if(TEXT)master_text(table);
	if(GRAPHICS)master_graphics(table);
}

void final_output(struct Sim *table)
{
	if(TEXT) final_text(table);
	if(GRAPHICS)final_graphics(table);
}

void load_message( struct Ball *bp)
{
	/* get the color */
	int color = get_color(bp->bits);
	if(GRAPHICS)pb_status("Loaded");
if(TEXT)printf("Loaded %02X %d ball at %9.5lf, %9.5lf %9.5lf deg %9.5lf ips\n",
    		bp->bits, color, bp->X, bp->Y, bp->theta, bp->force);

}

void launch_message( struct Ball *bp)
{
	/* get the color */
	int color = get_color(bp->bits);
	if(GRAPHICS)pb_status("Launch");
if(TEXT)printf("Launched %02X %d ball at %9.5lf, %9.5lf at %9.5lf, %9.5lf\n",
    		bp->bits, color, bp->X, bp->Y, bp->VX, bp->VY);

}


/* not technically public but it goes right next to the funcitons that call
 * it */
static void x_message( char *string,  struct Ball *bp)
{
	/* get the color */
	int color = get_color(bp->bits);
    if(TEXT) printf("%s: %02X    %9.5lf %9.5lf    %9.5lf %10.5lf\n",
	    string, bp->bits, bp->X, bp->Y, bp->VX, bp->VY );

	if(GRAPHICS)pb_status(string);
}

void left_message( struct Ball *bp)
{
    x_message("Left_ wall", bp);
}

void right_message( struct Ball *bp)
{
    x_message("Right wall", bp);
}

void top_message( struct Ball *bp)
{
    x_message("Upper wall", bp);
}

void off_message( struct Ball *bp)
{
    x_message("Off table", bp);
}

void left_flipper_message( struct Ball *bp)
{
    x_message("Left_ flipper", bp);
    if(GRAPHICS) pb_left();
}

void right_flipper_message( struct Ball *bp)
{
    x_message("Right flipper", bp);
    if(GRAPHICS) pb_right();
}

void points_message(int points)
{
	if(TEXT)printf("%d points\n", points);
	// graphics mode does score every frame
}

